package br.fiap.comissao;

public interface Comissao {
	public double calcularComissao(double valor);
}
