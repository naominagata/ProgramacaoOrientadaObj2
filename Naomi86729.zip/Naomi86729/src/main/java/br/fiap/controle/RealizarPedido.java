package br.fiap.controle;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.fiap.modelo.Pedido;
import br.fiap.modelo.PedidoDetalhe;
import br.fiap.modelo.Produto;


@WebServlet("/RealizarPedido")
public class RealizarPedido extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RealizarPedido() {
        super();
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PedidoDetalhe pedidoDetalhe = new PedidoDetalhe();
		Pedido pedido = new Pedido();
		Produto produto = new Produto();
		
		String nomeProduto = request.getParameter();
		String nomeContato = request.getParameter();
		String enderecoContato = request.getParameter();
		Double data = Double.parseDouble(request.getParameter());
		Integer quantidade = Integer.parseInt(request.getParameter("quantidade"));
		
		pedidoDetalhe.setPedido(pedido);
		pedidoDetalhe.setQtd(quantidade);
	}

}
