package br.fiap.controle;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.fiap.dao.CategoriaDAO;
import br.fiap.modelo.Categoria;


@WebServlet("/CadastrarCategoria")
public class CadastrarCategoria extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public CadastrarCategoria() {
        super();
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Categoria categoria = new Categoria();

		categoria.setNomeCategoria(request.getParameter("nomeCategoria"));
	
		new CategoriaDAO().cadastrarCategoria(categoria);
	}

}
