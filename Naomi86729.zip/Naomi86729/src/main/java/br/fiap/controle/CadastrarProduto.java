package br.fiap.controle;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.fiap.dao.ProdutoDAO;
import br.fiap.modelo.Categoria;
import br.fiap.modelo.Produto;


@WebServlet("/CadastrarProduto")
public class CadastrarProduto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public CadastrarProduto() {
        super();
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Produto produto = new Produto();
		Categoria categoria = new Categoria();
		
	    String produtoId = request.getParameter("produtoId");
	    String precoProduto = request.getParameter("precoProduto");
		produto.setNomeProduto(request.getParameter("nomeProduto"));
		produto.setDescricaoProduto(request.getParameter("descricaoProduto"));
		
		new ProdutoDAO().cadastrar(produto);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
	}

}
