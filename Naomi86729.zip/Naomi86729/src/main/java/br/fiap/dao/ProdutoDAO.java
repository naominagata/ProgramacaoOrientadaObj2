package br.fiap.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.Produto;

public class ProdutoDAO extends DAO{

	public void cadastrar(Produto produto) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "insert into java_produto values (produto_sequence.nextval, ?, ?, ?, ?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, produto.getCategoria().getIdCategoria());
			ps.setString(3, produto.getNomeProduto());
			ps.setString(4, produto.getDescricaoProduto());
			ps.setDouble(5, produto.getPrecoProduto());
			ps.execute();
			ps.close();
			conexao.desconectar();
		}
		catch(SQLException e) {
			System.out.println("Erro ao cadastrar produto");
		}
	}	
		
	public List<Produto> listar() {
		List<Produto> lista = new ArrayList<Produto>();
		Produto produto;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select * from java_produto";
		
		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				produto = new Produto();
				produto.setNomeProduto(rs.getString("nomeProduto"));
				produto.setDescricaoProduto(rs.getString("descricaoProduto"));
				produto.setPrecoProduto(rs.getDouble("precoProduto"));
				//produto.setCategoria(rs.getString("nomeCategoria"));
				lista.add(produto);
			}
			ps.close();
			conexao.desconectar();
		}catch(SQLException e) {
			System.out.println("Erro ao listar os produtos");
		}
		return lista;
	}
	
	public Produto pesquisarId(Integer produtoId) {
		Produto produto = null;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select * from java_produto where produtoId = ?";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, produtoId);
			rs= ps.executeQuery();
			if (rs.next()) {
				produto = new Produto();
				//produto.setCategoriaId(rs.getInt("categoriaId"));
				produto.setNomeProduto(rs.getString("nomeProduto"));
				produto.setDescricaoProduto(rs.getString("descricaoProduto"));
				produto.setPrecoProduto(rs.getDouble("precoProduto"));	
			}
			ps.close();
			conexao.desconectar();
		}
		catch (SQLException e) {
			System.out.println("Erro ao pesquisar id do produto" + e);
		}
		return produto;
	}
	
}
