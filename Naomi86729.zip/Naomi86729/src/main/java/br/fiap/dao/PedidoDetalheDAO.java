package br.fiap.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.Pedido;
import br.fiap.modelo.PedidoDetalhe;
import br.fiap.modelo.Produto;

public class PedidoDetalheDAO extends DAO{

	public void realizarPedido(Pedido pedido, PedidoDetalhe pedidoDetalhe) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "insert into java_pedido, java_pedidodetalhe values(produto_sequence.nextval,pedido_sequence.nextval,?,?,?,?,?)";
	
	   try {
		   ps = connection.prepareStatement(sql);
		   ps.setString(1, pedidoDetalhe.getPedido().getNomeContato());
		   ps.setString(2, pedidoDetalhe.getPedido().getEndContato());
		   ps.setDouble(3, pedidoDetalhe.getPedido().getData());
		   ps.setInt(4, pedidoDetalhe.getIdPedidoDetalhe());
		   ps.setInt(5, pedidoDetalhe.getQtd());
		   ps.setInt(6, pedidoDetalhe.getTotal());
		   ps.execute();
		   ps.close();
		   conexao.desconectar();
	   } catch(SQLException e) {
		   System.out.println("Erro ao realizar pedido" + e);
	   }
	}
	
	public List<PedidoDetalhe> listarPedido() {
		List<PedidoDetalhe> lista = new ArrayList<PedidoDetalhe>();
		Pedido pedido;
		PedidoDetalhe pedidoDetalhe;
		Produto produto;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select nomeContato, data from java_pedido"
				+ "select nomeProduto, qtd, total from java_produto";
		
		try {
			ps = connection.prepareStatement(sql);
		    rs = ps.executeQuery();
		    while (rs.next()) {
		    	pedido = new Pedido();
		    	pedidoDetalhe = new PedidoDetalhe();
		    	produto = new Produto();
		    	pedido.setNomeContato(rs.getString("nomeContato"));
		    	produto.setNomeProduto(rs.getString("nomeProduto"));
		    	pedido.setData(rs.getDouble("data"));
		    	pedidoDetalhe.setQtd(rs.getInt("qtd"));
		    	pedidoDetalhe.setTotal(rs.getInt("total"));
		    }
		}catch(SQLException e) {
			System.out.println("Erro ao listar pedido"+ e);
		}
		
		return null;
	}
	
	public void excluirPedido(Integer produtoId) {
		PedidoDetalhe pedidoDetalhe = null;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select * from java_pedidoDetalhe where idPedidoDetalhe = ?";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, produtoId);
			rs= ps.executeQuery();
			if (rs.next()) {
				pedidoDetalhe = new PedidoDetalhe();
				produto.setNomeProduto(rs.getString("nomeProduto"));
				produto.setDescricaoProduto(rs.getString("descricaoProduto"));
				produto.setPrecoProduto(rs.getDouble("precoProduto"));	
			}
			ps.close();
			conexao.desconectar();
		}
		catch (SQLException e) {
			System.out.println("Erro ao pesquisar id do produto" + e);
		}
	}
	
	
	public Produto pesquisarId(Integer produtoId) {
		Produto produto = null;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select * from java_produto where produtoId = ?";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, produtoId);
			rs= ps.executeQuery();
			if (rs.next()) {
				produto = new Produto();
				categoria.setCategoriaId(rs.getInt("categoriaId"));
				produto.setNomeProduto(rs.getString("nomeProduto"));
				produto.setDescricaoProduto(rs.getString("descricaoProduto"));
				produto.setPrecoProduto(rs.getDouble("precoProduto"));	
			}
			ps.close();
			conexao.desconectar();
		}
		catch (SQLException e) {
			System.out.println("Erro ao pesquisar id do produto" + e);
		}
		return produto;
	}
}
