package br.fiap.dao;

import java.sql.SQLException;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.Categoria;

public class CategoriaDAO extends DAO{

	public void cadastrarCategoria(Categoria categoria) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "insert into java_categoria values (categoria_sequence.nextval,?) ";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(2, categoria.getNomeCategoria());
			ps.execute();
			ps.close();
			conexao.desconectar();
		} catch(SQLException e) {
			System.out.println("Erro ao cadastrar categoria");
		}
	}
}
