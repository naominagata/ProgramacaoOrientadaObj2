package br.fiap.modelo;

public class PedidoDetalhe {

	private Integer idPedidoDetalhe;
	private Integer qtd;
	private Integer total;
	private Pedido pedido;
	private Produto produto;
	
	public Produto getProduto() {
		return produto;
	}
	public void setProduto(Produto produto) {
		this.produto = produto;
	}
	public Pedido getPedido() {
		return pedido;
	}
	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}
	public void setIdPedidoDetalhe(Integer idPedidoDetalhe) {
		this.idPedidoDetalhe = idPedidoDetalhe;
	}
	public Integer getIdPedidoDetalhe() {
		return idPedidoDetalhe;
	}
	public void setId(Integer idPedidoDetalhe) {
		this.idPedidoDetalhe = idPedidoDetalhe;
	}
	public Integer getQtd() {
		return qtd;
	}
	public void setQtd(Integer qtd) {
		this.qtd = qtd;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	
	
}
