package br.fiap.modelo;

public class Pedido {

	//java_pedido
	private Integer idPedido;
	private String nomeContato;
	private String endContato;
	private Double data;
	
	public Integer getIdPedido() {
		return idPedido;
	}
	public void setIdPedido(Integer idPedido) {
		this.idPedido = idPedido;
	}
	public String getNomeContato() {
		return nomeContato;
	}
	public void setNomeContato(String nomeContato) {
		this.nomeContato = nomeContato;
	}
	public String getEndContato() {
		return endContato;
	}
	public void setEndContato(String endContato) {
		this.endContato = endContato;
	}
	public Double getData() {
		return data;
	}
	public void setData(Double data) {
		this.data = data;
	}

	
}
